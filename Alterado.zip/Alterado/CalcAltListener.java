// Generated from CalcAlt.g4 by ANTLR 4.13.2
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link CalcAltParser}.
 */
public interface CalcAltListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link CalcAltParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExpr(CalcAltParser.ExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link CalcAltParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExpr(CalcAltParser.ExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Neg}
	 * labeled alternative in {@link CalcAltParser#unary}.
	 * @param ctx the parse tree
	 */
	void enterNeg(CalcAltParser.NegContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Neg}
	 * labeled alternative in {@link CalcAltParser#unary}.
	 * @param ctx the parse tree
	 */
	void exitNeg(CalcAltParser.NegContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Pos}
	 * labeled alternative in {@link CalcAltParser#unary}.
	 * @param ctx the parse tree
	 */
	void enterPos(CalcAltParser.PosContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Pos}
	 * labeled alternative in {@link CalcAltParser#unary}.
	 * @param ctx the parse tree
	 */
	void exitPos(CalcAltParser.PosContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Num}
	 * labeled alternative in {@link CalcAltParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterNum(CalcAltParser.NumContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Num}
	 * labeled alternative in {@link CalcAltParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitNum(CalcAltParser.NumContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Paren}
	 * labeled alternative in {@link CalcAltParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterParen(CalcAltParser.ParenContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Paren}
	 * labeled alternative in {@link CalcAltParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitParen(CalcAltParser.ParenContext ctx);
}