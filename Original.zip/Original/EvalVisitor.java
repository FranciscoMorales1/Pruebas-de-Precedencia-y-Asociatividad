import static java.lang.Math.*;

public class EvalVisitor extends CalcBaseVisitor<Double> {
    @Override
    public Double visitExpr(CalcParser.ExprContext ctx) {
        return visit(ctx.addExpr());
    }

    @Override
    public Double visitAddExpr(CalcParser.AddExprContext ctx) {
        double value = visit(ctx.left);
        for (int i = 0; i < ctx.ops.size(); i++) {
            String op = ctx.ops.get(i).getText();
            double r = visit(ctx.rights.get(i));
            value = op.equals("+") ? value + r : value - r;
        }
        return value;
    }

    @Override
    public Double visitMulExpr(CalcParser.MulExprContext ctx) {
        double value = visit(ctx.left);
        for (int i = 0; i < ctx.ops.size(); i++) {
            String op = ctx.ops.get(i).getText();
            double r = visit(ctx.rights.get(i));
            value = op.equals("*") ? value * r : value / r;
        }
        return value;
    }

    @Override
    public Double visitPowExpr(CalcParser.PowExprContext ctx) {
        double base = visit(ctx.base);
        if (ctx.exponent != null) {
            double exp = visit(ctx.exponent);
            return pow(base, exp);
        }
        return base;
    }

    @Override
    public Double visitNeg(CalcParser.NegContext ctx) {
        return -visit(ctx.u);
    }

    @Override
    public Double visitPos(CalcParser.PosContext ctx) {
        return visit(ctx.atom());
    }

    @Override
    public Double visitNum(CalcParser.NumContext ctx) {
        return Double.parseDouble(ctx.NUMBER().getText());
    }

    @Override
    public Double visitParen(CalcParser.ParenContext ctx) {
        return visit(ctx.expr());
    }
}
