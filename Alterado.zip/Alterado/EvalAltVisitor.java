import static java.lang.Math.*;

public class EvalAltVisitor extends CalcAltBaseVisitor<Double> {
    @Override
    public Double visitExpr(CalcAltParser.ExprContext ctx) {
        double value = visit(ctx.left);
        for (int i = 0; i < ctx.ops.size(); i++) {
            String op = ctx.ops.get(i).getText();
            double r = visit(ctx.rights.get(i));
            switch (op) {
                case "+": value = value + r; break;
                case "-": value = value - r; break;
                case "*": value = value * r; break;
                case "/": value = value / r; break;
                case "^": value = pow(value, r); break; // ^ izquierda
            }
        }
        return value;
    }

    @Override
    public Double visitNeg(CalcAltParser.NegContext ctx) {
        return -visit(ctx.u);
    }

    @Override
    public Double visitPos(CalcAltParser.PosContext ctx) {
        return visit(ctx.atom());
    }

    @Override
    public Double visitNum(CalcAltParser.NumContext ctx) {
        return Double.parseDouble(ctx.NUMBER().getText());
    }

    @Override
    public Double visitParen(CalcAltParser.ParenContext ctx) {
        return visit(ctx.expr());
    }
}
