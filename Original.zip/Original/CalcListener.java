// Generated from Calc.g4 by ANTLR 4.13.2
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link CalcParser}.
 */
public interface CalcListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link CalcParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExpr(CalcParser.ExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link CalcParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExpr(CalcParser.ExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link CalcParser#addExpr}.
	 * @param ctx the parse tree
	 */
	void enterAddExpr(CalcParser.AddExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link CalcParser#addExpr}.
	 * @param ctx the parse tree
	 */
	void exitAddExpr(CalcParser.AddExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link CalcParser#mulExpr}.
	 * @param ctx the parse tree
	 */
	void enterMulExpr(CalcParser.MulExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link CalcParser#mulExpr}.
	 * @param ctx the parse tree
	 */
	void exitMulExpr(CalcParser.MulExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link CalcParser#powExpr}.
	 * @param ctx the parse tree
	 */
	void enterPowExpr(CalcParser.PowExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link CalcParser#powExpr}.
	 * @param ctx the parse tree
	 */
	void exitPowExpr(CalcParser.PowExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Neg}
	 * labeled alternative in {@link CalcParser#unary}.
	 * @param ctx the parse tree
	 */
	void enterNeg(CalcParser.NegContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Neg}
	 * labeled alternative in {@link CalcParser#unary}.
	 * @param ctx the parse tree
	 */
	void exitNeg(CalcParser.NegContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Pos}
	 * labeled alternative in {@link CalcParser#unary}.
	 * @param ctx the parse tree
	 */
	void enterPos(CalcParser.PosContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Pos}
	 * labeled alternative in {@link CalcParser#unary}.
	 * @param ctx the parse tree
	 */
	void exitPos(CalcParser.PosContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Num}
	 * labeled alternative in {@link CalcParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterNum(CalcParser.NumContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Num}
	 * labeled alternative in {@link CalcParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitNum(CalcParser.NumContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Paren}
	 * labeled alternative in {@link CalcParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterParen(CalcParser.ParenContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Paren}
	 * labeled alternative in {@link CalcParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitParen(CalcParser.ParenContext ctx);
}