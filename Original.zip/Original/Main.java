import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import java.io.*;

public class Main {
    public static void main(String[] args) throws Exception {
        System.out.println("Calc (original). Escribe una expresión por línea. Ctrl+Z y Enter para terminar.");
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String line;
        while ((line = br.readLine()) != null) {
            if (line.trim().isEmpty()) continue;
            CharStream input = CharStreams.fromString(line);
            CalcLexer lexer = new CalcLexer(input);
            CommonTokenStream tokens = new CommonTokenStream(lexer);
            CalcParser parser = new CalcParser(tokens);
            ParseTree tree = parser.expr();
            double result = new EvalVisitor().visit(tree);
            if (Math.rint(result) == result) {
                System.out.println("= " + String.format("%.0f", result));
            } else {
                System.out.println("= " + result);
            }
        }
    }
}
