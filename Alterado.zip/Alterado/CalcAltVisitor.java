// Generated from CalcAlt.g4 by ANTLR 4.13.2
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link CalcAltParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface CalcAltVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link CalcAltParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpr(CalcAltParser.ExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Neg}
	 * labeled alternative in {@link CalcAltParser#unary}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNeg(CalcAltParser.NegContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Pos}
	 * labeled alternative in {@link CalcAltParser#unary}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPos(CalcAltParser.PosContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Num}
	 * labeled alternative in {@link CalcAltParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNum(CalcAltParser.NumContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Paren}
	 * labeled alternative in {@link CalcAltParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParen(CalcAltParser.ParenContext ctx);
}